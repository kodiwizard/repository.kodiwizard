# script.module.matthuisman
Common code required by various MattHuisman.nz addons
