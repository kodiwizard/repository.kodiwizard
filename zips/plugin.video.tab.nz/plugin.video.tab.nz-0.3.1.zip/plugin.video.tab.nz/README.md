# plugin.video.tab.nz

Unofficial 3rd Party TAB New Zealand plugin for Kodi.

https://www.matthuisman.nz/2019/01/tab-nz-kodi-add-on.html